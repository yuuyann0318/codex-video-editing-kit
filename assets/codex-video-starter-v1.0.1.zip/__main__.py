#!/usr/bin/env python3
"""Codex動画編集スターターの安全なZIPインストーラー。"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import stat
import sys
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath

SKILL_NAME = "codex-video-starter"
MAX_FILES = 200
MAX_FILE_SIZE = 100 * 1024 * 1024
MAX_TOTAL_SIZE = 250 * 1024 * 1024
ROOT_FILES = {"__main__.py", "README_INSTALL.txt"}


class InstallError(RuntimeError):
    pass


def sha256_stream(handle) -> str:
    digest = hashlib.sha256()
    while True:
        chunk = handle.read(1024 * 1024)
        if not chunk:
            break
        digest.update(chunk)
    return digest.hexdigest()


def validate_name(name: str) -> PurePosixPath:
    if "\\" in name or "\x00" in name:
        raise InstallError(f"不正なZIP内パスです: {name!r}")
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or ".." in path.parts:
        raise InstallError(f"ZIP外へ出るパスを拒否しました: {name!r}")
    if path.parts[0] not in ROOT_FILES and path.parts[0] != SKILL_NAME:
        raise InstallError(f"想定外のZIP直下項目です: {name!r}")
    return path


def validate_archive(archive: Path) -> tuple[zipfile.ZipFile, dict[str, str]]:
    try:
        bundle = zipfile.ZipFile(archive)
    except (OSError, zipfile.BadZipFile) as exc:
        raise InstallError(f"ZIPを開けません: {exc}") from exc
    entries = bundle.infolist()
    if len(entries) > MAX_FILES:
        bundle.close()
        raise InstallError(f"ファイル数が上限を超えています: {len(entries)}")
    seen: set[str] = set()
    portable_seen: set[str] = set()
    entry_kinds: dict[str, bool] = {}
    total = 0
    for info in entries:
        path = validate_name(info.filename)
        normalized = path.as_posix().rstrip("/")
        if normalized in seen:
            bundle.close()
            raise InstallError(f"重複パスを拒否しました: {normalized}")
        seen.add(normalized)
        portable = unicodedata.normalize("NFC", normalized).casefold()
        if portable in portable_seen:
            bundle.close()
            raise InstallError(f"大文字小文字またはUnicode正規化で衝突します: {normalized}")
        portable_seen.add(portable)
        mode = (info.external_attr >> 16) & 0o170000
        if mode == stat.S_IFLNK:
            bundle.close()
            raise InstallError(f"シンボリックリンクを拒否しました: {info.filename}")
        if mode not in {0, stat.S_IFREG, stat.S_IFDIR}:
            bundle.close()
            raise InstallError(f"通常ファイル以外を拒否しました: {info.filename}")
        entry_kinds[portable] = info.is_dir()
        if info.file_size > MAX_FILE_SIZE:
            bundle.close()
            raise InstallError(f"単体ファイルが大きすぎます: {info.filename}")
        total += info.file_size
    if total > MAX_TOTAL_SIZE:
        bundle.close()
        raise InstallError(f"展開サイズが上限を超えています: {total} bytes")
    for name, is_directory in entry_kinds.items():
        parts = name.split("/")
        for index in range(1, len(parts)):
            parent = "/".join(parts[:index])
            if parent in entry_kinds and not entry_kinds[parent]:
                bundle.close()
                raise InstallError(f"ファイルとフォルダが衝突します: {name}")
        if not is_directory and any(other.startswith(name + "/") for other in entry_kinds):
            bundle.close()
            raise InstallError(f"ファイルとフォルダが衝突します: {name}")

    manifest_name = f"{SKILL_NAME}/manifest.json"
    try:
        manifest = json.loads(bundle.read(manifest_name).decode("utf-8"))
        files = manifest["files"]
    except (KeyError, UnicodeDecodeError, json.JSONDecodeError, TypeError) as exc:
        bundle.close()
        raise InstallError("manifest.jsonが不正です") from exc
    if not isinstance(files, dict) or not files:
        bundle.close()
        raise InstallError("manifest.jsonにファイル一覧がありません")
    manifest_portable: set[str] = set()
    for relative, expected_hash in files.items():
        if not isinstance(relative, str) or not isinstance(expected_hash, str):
            bundle.close()
            raise InstallError("manifest.jsonのファイル名またはハッシュが不正です")
        relative_path = PurePosixPath(relative)
        if relative_path.is_absolute() or relative == "manifest.json":
            bundle.close()
            raise InstallError(f"manifest.jsonのパスが不正です: {relative!r}")
        validate_name(f"{SKILL_NAME}/{relative}")
        portable = unicodedata.normalize("NFC", relative_path.as_posix()).casefold()
        if portable in manifest_portable:
            bundle.close()
            raise InstallError(f"manifest.json内のパスが衝突します: {relative}")
        manifest_portable.add(portable)
    expected = {f"{SKILL_NAME}/{name}" for name in files} | {manifest_name}
    actual = {
        info.filename.rstrip("/")
        for info in entries
        if info.filename.startswith(f"{SKILL_NAME}/") and not info.is_dir()
    }
    if actual != expected:
        bundle.close()
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        raise InstallError(f"manifestとZIPが一致しません。missing={missing} extra={extra}")
    for relative, expected_hash in files.items():
        validate_name(f"{SKILL_NAME}/{relative}")
        with bundle.open(f"{SKILL_NAME}/{relative}") as handle:
            actual_hash = sha256_stream(handle)
        if actual_hash != expected_hash:
            bundle.close()
            raise InstallError(f"ハッシュが一致しません: {relative}")
    return bundle, files


def existing_matches(target: Path, files: dict[str, str]) -> bool:
    expected = {Path(name) for name in files} | {Path("manifest.json")}
    actual = {
        item.relative_to(target)
        for item in target.rglob("*")
        if item.is_file() and "__pycache__" not in item.parts
    }
    if actual != expected:
        return False
    for relative, expected_hash in files.items():
        path = target / relative
        if not path.is_file():
            return False
        with path.open("rb") as handle:
            if sha256_stream(handle) != expected_hash:
                return False
    return True


def extract(bundle: zipfile.ZipFile, files: dict[str, str], staging: Path) -> None:
    for relative in sorted(files):
        destination = staging / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with bundle.open(f"{SKILL_NAME}/{relative}") as source, destination.open("wb") as target:
            shutil.copyfileobj(source, target)
    with bundle.open(f"{SKILL_NAME}/manifest.json") as source, (staging / "manifest.json").open("wb") as target:
        shutil.copyfileobj(source, target)
    for relative in files:
        with (staging / relative).open("rb") as handle:
            if sha256_stream(handle) != files[relative]:
                raise InstallError(f"展開後のハッシュが一致しません: {relative}")


def default_target_root() -> Path:
    base = os.environ.get("CODEX_HOME")
    return (Path(base).expanduser() if base else Path.home() / ".codex") / "skills"


def main() -> int:
    parser = argparse.ArgumentParser(description="Codex動画編集スターターを安全に導入します")
    parser.add_argument("--target-root", help="スキルを置く親フォルダ")
    parser.add_argument("--dry-run", action="store_true", help="検査だけ行う")
    args = parser.parse_args()
    archive = Path(sys.argv[0]).resolve()
    target_root = (
        Path(args.target_root).expanduser().resolve()
        if args.target_root
        else default_target_root().resolve()
    )
    target = target_root / SKILL_NAME
    bundle = None
    staging = None
    try:
        bundle, files = validate_archive(archive)
        print(f"同梱ファイルの整合性: 合格 ({len(files)}ファイル)")
        print("注意: この検査は配布元の真正性を証明しません。実行前の外側SHA-256照合が必要です")
        print("導入先:", target)
        if args.dry_run:
            return 0
        target_root.mkdir(parents=True, exist_ok=True)
        if target.exists():
            if target.is_dir() and existing_matches(target, files):
                print("同じ内容が導入済みです。変更はありません")
                return 0
            raise InstallError("同名の既存スキルがあります。上書きせず停止しました")
        staging = Path(tempfile.mkdtemp(prefix=f".{SKILL_NAME}-", dir=str(target_root)))
        extract(bundle, files, staging)
        os.replace(staging, target)
        staging = None
        print("導入完了:", target)
        print("次に実行:", target / "scripts" / "doctor.py")
        return 0
    except (InstallError, OSError) as exc:
        print("導入を停止しました:", exc, file=sys.stderr)
        return 1
    finally:
        if bundle is not None:
            bundle.close()
        if staging is not None and staging.exists():
            shutil.rmtree(staging)


if __name__ == "__main__":
    raise SystemExit(main())
