# Codex動画編集スターター v1.0.1

ZIPをCodexへ渡し、アフレコ動画とトーク動画をローカルで編集するための配布キットです。

## 最初に外側のSHA-256を確認

ZIPを実行する前に、公式の固定配布元ページを開いてください。

https://yuuyann0318.github.io/codex-video-editing-kit/

ページに表示されたZIPのSHA-256と、手元のZIPをCodexが計算したSHA-256を照合します。64文字が1文字でも違う場合は実行せず、ZIPを削除して公式ページから取り直してください。一致した場合だけ導入を続けます。

ZIP内のmanifest検査は、同梱ファイルの破損や欠落を調べるものです。ZIP直下の起動ファイルを含む配布物全体の出どころは保証できないため、外側SHA-256の照合を先に行います。

完成見本は `sample/completed/voiceover-sample.mp4`、同期確認用のトーク見本は `sample/completed/talk-sync-sample.mp4` にあります。アフレコ見本の音声出典は `sample/THIRD_PARTY_NOTICES.md` に記録しています。

## 確認済みの環境

- macOS 27.0.1（Apple Silicon）
- Codex CLI 0.165.0
- Python 3.9.6
- FFmpeg / FFprobe 9.0.2（キット専用フォルダへの導入を実測）

上記は2026-10-29 JSTの実機確認です。WindowsとLinuxはコード上の候補を用意していますが、実機では確認していません。

## Codexをまだ使っていない場合

先にOpenAI公式の[Codex CLI案内](https://developers.openai.com/codex/cli)を確認してください。Codexの導入、サインイン、利用できるプランはOpenAI側の案内に従います。

このキット専用の追加APIキーや独自の従量API連携は使いません。自動文字起こしと動画書き出しはMac内で動きます。Codexへ送る指示や読ませる情報は、利用中のAIサービスの条件に従います。自分の音声を初めて文字起こしする時だけ、専用の音声認識モデルを取得します。

## このZIPの扱い

このZIPはローカル導入用です。Codexのスキルは `SKILL.md` と補助ファイルで構成されます。考え方はOpenAI公式の[Skills](https://developers.openai.com/plugins/concepts/skills)に沿っています。

ZIPをAPIへアップロードする形式ではありません。公開プラグインとして登録する場合は、OpenAI公式の[プラグインのパッケージ案内](https://developers.openai.com/plugins/build/plugins)を確認し、別途審査してください。

## 手動で確認したい人へ

Codexが実行する導入コマンドは次の形です。

先に上記の固定配布元ページと外側SHA-256が一致したことを確認してください。

```sh
python3 "/ZIPの場所/codex-video-starter-v1.0.1.zip"
```

既定ではCodexの個人スキル領域へ入ります。既に同名のフォルダがあり内容が違う場合は停止します。勝手に上書きしません。

空の場所で試す場合は次の形です。

```sh
python3 "/ZIPの場所/codex-video-starter-v1.0.1.zip" --target-root "/空のテスト先"
```

同じZIPを同じ場所へもう一度実行した場合は、内容が同じことを確認して終了します。

「すでに導入済み」または「内容が違う」と停止した場合は、元を削除したり上書きしたりせず、既存の場所と差分をCodexへ確認してもらってください。

## 必要な道具

- Python 3.9以上
- FFmpegとFFprobe
- 日本語フォント

基本レンダラーはPillowやNumPyなどの追加Pythonパッケージが不要です。

自動文字起こしを使う場合は、専用venvへMLX Whisperまたはfaster-whisperを入れます。システムPythonは変更しません。

初回は取得中のパッケージ名が表示されます。高品質モデルを含めると容量が大きく、所要時間は回線と端末で変わります。途中で止まった場合は同じ導入を再試行でき、通常の失敗では未完成の専用環境を残しません。

FFmpegは同梱していません。Apple SiliconのMacでは、見つからない時だけ `scripts/setup_tools.py` がキット専用フォルダへ導入できます。FFmpeg公式ページが案内する外部ビルド提供者の安定版URLとSHA-256を固定し、取得後も検査します。システム領域やHomebrewは変更しません。

この自動導入はmacOS 27.0.1 / Apple Siliconで実機確認しています。WindowsとLinuxは未確認のため、自動導入を断定しません。Codexが[FFmpeg公式ダウンロード案内](https://ffmpeg.org/download.html)を基に環境ごとの方法を案内します。

## 安全設計

- ZIP内の絶対パス、`..`、シンボリックリンクを拒否
- ファイル数と展開サイズに上限
- 既存の同名フォルダへ上書きしない
- 元素材と既存MP4を上書きしない
- 一時作業は別フォルダ
- 編集と文字起こしはローカル実行。APIキーと従量課金なし
- 初回の音声認識環境とモデル取得だけ外部通信あり

詳しい制限は `references/limits.md` にあります。

外部ソフトと練習音声の出典は `references/dependencies.md` と `sample/THIRD_PARTY_NOTICES.md` に記録しています。
