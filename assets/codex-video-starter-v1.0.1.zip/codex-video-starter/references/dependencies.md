# 外部ソフトと取得先

## 動画の書き出し

- FFmpeg / FFprobe
- 公式案内: https://ffmpeg.org/download.html
- このZIPにはバイナリを同梱しません。

Apple Silicon Mac向けの自動導入はFFmpeg 9.0.2を使います。

- FFmpegプロジェクトはソースコードを配布し、実行ファイルは外部提供者を案内しています。
- バイナリ提供: Martin Riedl's FFmpeg Build Server（https://ffmpeg.martin-riedl.de/）
- `setup_tools.py` は固定した配布URLとSHA-256を照合し、Codex専用データ領域へだけ展開します。
- macOS 27.0.1 / Apple Silicon以外の自動導入は未検証です。

## 自動文字起こし

音声認識は専用venvへ入れます。システムPythonへ直接追加しません。

`setup_stt.py` はPyPI公式index `https://pypi.org/simple` を明示して取得します。導入後はpipの `--report` が返した実際のパッケージ名、版、取得URLを `install-record.json` と `pip-install-report.json` に残します。推移的依存を完全固定するlockファイルは今回の配布には含みません。

- Apple Silicon Mac: `mlx-whisper==0.4.3`
  - PyPI: https://pypi.org/project/mlx-whisper/0.4.3/
  - ソース: https://github.com/ml-explore/mlx-examples/tree/main/whisper
- そのほか: `faster-whisper==1.2.0`
  - PyPI: https://pypi.org/project/faster-whisper/1.2.0/
  - ソース: https://github.com/SYSTRAN/faster-whisper

音声認識モデルは、最初の文字起こし時に取得します。既定はMLX版の `mlx-community/whisper-large-v3-turbo`、faster-whisper版の `small` です。MLX版は日本語練習音声で実測した高品質モデルで、モデル保存量は実機で約1.5GBでした。処理時間は音声の長さと端末性能で変わります。これらの実装はOpenAI製品ではありません。Whisperモデルの元研究・コードは https://github.com/openai/whisper です。

取得は無料で、OpenAI APIキーや従量課金はありません。通信を避ける場合は、確認済みSRTを `auto_edit.py --srt` で渡してください。

## 練習音声

`sample/assets/practice-ja.wav` の出典とライセンスは `sample/THIRD_PARTY_NOTICES.md` にあります。

記録日: 2026-10-29 JST
