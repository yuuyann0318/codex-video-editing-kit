# 練習音声の出典

`assets/practice-ja.wav` は、Lux Japanese Speech Corpus の
`RECITATION324_310.wav` です。

- 作品名: Lux Japanese Speech Corpus
- 作者: Lami
- 公開年: 2025
- ライセンス: Creative Commons Attribution 4.0 International（CC BY 4.0）
- 配布元: https://huggingface.co/datasets/Lami/Lux-Japanese-Speech-Corpus
- ライセンス本文: https://creativecommons.org/licenses/by/4.0/
- 取得日: 2026-10-29
- 取得元ファイル: `data/cleaned/ita_recitation/RECITATION324_310.wav`
- 同梱ファイルSHA-256: `1bd6481017c7dc34a450faf53f60e6a07238d86bba1f086154659e376f842f4e`
- 原文: 「カフェとは、ブレックファストとして、フォカッチャを食べれる場所でもある。」

音声そのものは改変していません。完成動画では縦動画の音声として使用しています。
音声以外の練習素材と編集設定は、このキット用に制作したものです。

練習画像5点は、このキットと案内サイト用に生成した架空のイメージです。実在の人物、店舗、実績を示すものではありません。

- `practice-01.png`〜`practice-03.png`: 汎用の練習用
- `sample-cafe.png`: 完成見本のカフェ／朝食用
- `sample-focaccia-breakfast.png`: 完成見本のフォカッチャ用

完成見本の画面内に「画像はイメージです」と表示します。
