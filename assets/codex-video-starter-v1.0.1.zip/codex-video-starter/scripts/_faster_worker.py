#!/usr/bin/env python3
"""faster-whisper専用venv内で実行する内部ワーカー。"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from faster_whisper import WhisperModel

def main()->int:
    p=argparse.ArgumentParser();p.add_argument("media");p.add_argument("--model",default="small");p.add_argument("--language",default="ja");p.add_argument("--output",required=True);a=p.parse_args()
    model=WhisperModel(a.model,device="auto",compute_type="int8")
    segments,info=model.transcribe(a.media,language=a.language,word_timestamps=True,vad_filter=True)
    rows=[]
    for s in segments:
        words=[{"word":w.word,"start":w.start,"end":w.end,"probability":w.probability} for w in (s.words or [])]
        rows.append({"start":s.start,"end":s.end,"text":s.text.strip(),"words":words})
    result={"text":"".join(r["text"] for r in rows),"segments":rows,"language":info.language}
    Path(a.output).write_text(json.dumps(result,ensure_ascii=False)+"\n",encoding="utf-8");return 0
if __name__=="__main__": raise SystemExit(main())
