#!/usr/bin/env python3
"""素材から文字起こし、字幕設定、下書きMP4までを一度に作る。"""
from __future__ import annotations
import argparse,json,os,re,subprocess,sys,unicodedata
from pathlib import Path
from doctor import font_candidates,tool_path

def units(text:str)->float:return sum(1 if unicodedata.east_asian_width(c) in {"F","W","A"} else .55 for c in text)
def seconds(raw:str)->float:
    h,m,s=raw.strip().replace(",",".").split(":");return int(h)*3600+int(m)*60+float(s)
def parse_srt(path:Path)->list[dict]:
    rows=[]
    for block in re.split(r"\n\s*\n",path.read_text(encoding="utf-8-sig").strip()):
        lines=[x.strip() for x in block.splitlines() if x.strip()];idx=next((i for i,x in enumerate(lines) if "-->" in x),None)
        if idx is None:continue
        a,b=lines[idx].split("-->",1);text="".join(lines[idx+1:]).strip()
        if text:rows.append({"start":seconds(a),"end":seconds(b),"text":text,"words":[]})
    if not rows:raise RuntimeError("SRTから字幕を読めません")
    return rows
def parse_scene_map(path:Path,allowed_images:list[Path],length:float)->list[dict]:
    try:data=json.loads(path.read_text(encoding="utf-8"))
    except (OSError,json.JSONDecodeError) as e:raise RuntimeError(f"scene mapを読めません: {e}") from e
    rows=data.get("scenes") if isinstance(data,dict) else data
    if not isinstance(rows,list) or not rows:raise RuntimeError("scene mapのscenesが空です")
    allowed={x.resolve() for x in allowed_images};result=[];last_end=0.0
    for index,row in enumerate(rows,1):
        if not isinstance(row,dict):raise RuntimeError(f"scene {index}が不正です")
        image=Path(str(row.get("image",""))).expanduser();image=image.resolve() if image.is_absolute() else (path.parent/image).resolve()
        start=float(row.get("start",-1));end=float(row.get("end",-1));reason=str(row.get("reason","")).strip();speech=str(row.get("speech","")).strip()
        if image not in allowed or not image.is_file():raise RuntimeError(f"scene {index}の画像が--imageにありません")
        if not (0<=start<end<=length+.05) or start<last_end:raise RuntimeError(f"scene {index}の時刻が重複、逆順、または動画外です")
        if not speech or not reason:raise RuntimeError(f"scene {index}にはspeechとreasonが必要です")
        result.append({"image":image,"start":start,"end":min(end,length),"speech":speech,"reason":reason});last_end=end
    return result
def chunks_words(words:list[dict],limit:float)->list[dict]:
    chunks=[];current=[]
    for word in words:
        token=str(word.get("word",""))
        if current and units("".join(str(x.get("word","")) for x in current)+token)>limit:
            chunks.append({"start":float(current[0]["start"]),"end":float(current[-1]["end"]),"text":"".join(str(x["word"]) for x in current).strip()});current=[]
        current.append(word)
        if token.endswith(("。","！","？","、","!","?")) and units("".join(str(x["word"]) for x in current))>=6:
            chunks.append({"start":float(current[0]["start"]),"end":float(current[-1]["end"]),"text":"".join(str(x["word"]) for x in current).strip()});current=[]
        elif any("".join(str(x["word"]) for x in current).strip().endswith(mark) for mark in {"は","を","として","ので","けど"}) and units("".join(str(x["word"]) for x in current))>=5:
            chunks.append({"start":float(current[0]["start"]),"end":float(current[-1]["end"]),"text":"".join(str(x["word"]) for x in current).strip()});current=[]
    if current:chunks.append({"start":float(current[0]["start"]),"end":float(current[-1]["end"]),"text":"".join(str(x["word"]) for x in current).strip()})
    return chunks
def chunks_proportional(seg:dict,limit:float)->list[dict]:
    text=str(seg["text"]).strip();pieces=[]
    while units(text)>limit:
        cut=1
        for i in range(1,len(text)+1):
            if units(text[:i])<=limit:cut=i
            else:break
        punctuation=max(text.rfind(mark,0,cut+1) for mark in "。、！？!?")
        if punctuation>=max(1,cut//2):cut=punctuation+1
        pieces.append(text[:cut].strip());text=text[cut:].strip()
    if text:pieces.append(text)
    total=sum(max(units(x),1) for x in pieces);cursor=float(seg["start"]);duration=float(seg["end"])-cursor;rows=[]
    for i,piece in enumerate(pieces):
        end=float(seg["end"]) if i==len(pieces)-1 else cursor+duration*max(units(piece),1)/total
        rows.append({"start":cursor,"end":end,"text":piece});cursor=end
    return rows
def caption_rows(segments:list[dict],limit:float=13)->list[dict]:
    rows=[]
    for seg in segments:rows.extend(chunks_words(seg.get("words") or [],limit) if seg.get("words") else chunks_proportional(seg,limit))
    for left,right in zip(rows,rows[1:]):left["end"]=min(left["end"],right["start"])
    return rows
def duration(ffprobe:str,media:Path)->float:
    r=subprocess.run([ffprobe,"-v","error","-show_entries","format=duration","-of","default=nw=1:nk=1",str(media)],check=True,text=True,capture_output=True);return float(r.stdout.strip())
def main()->int:
    p=argparse.ArgumentParser(description="素材から下書きMP4まで自動で作ります");p.add_argument("media");p.add_argument("--mode",choices=["voiceover","talk"],required=True);p.add_argument("--background");p.add_argument("--image",action="append",default=[]);p.add_argument("--scene-map",help="Codexが画像を実見して作った発話と画像の対応JSON");p.add_argument("--srt");p.add_argument("--workdir",required=True);p.add_argument("--engine",choices=["auto","mlx","faster"],default="auto");p.add_argument("--model");p.add_argument("--runtime",help="音声認識の専用venv");p.add_argument("--ffmpeg-dir");a=p.parse_args()
    media=Path(a.media).expanduser().resolve();work=Path(a.workdir).expanduser().resolve()
    if not media.is_file():print(f"素材が見つかりません: {media}",file=sys.stderr);return 1
    if work.exists() and any(work.iterdir()):print(f"作業フォルダが空ではありません: {work}",file=sys.stderr);return 1
    work.mkdir(parents=True,exist_ok=True);ffmpeg=tool_path("ffmpeg",a.ffmpeg_dir,False);ffprobe=tool_path("ffprobe",a.ffmpeg_dir,False);fonts=font_candidates()
    if not ffmpeg or not ffprobe or not fonts:print("doctor.pyで環境を確認してください",file=sys.stderr);return 1
    background=Path(a.background).expanduser().resolve() if a.background else None
    if a.mode=="voiceover" and (background is None or not background.is_file()):print("voiceoverには--backgroundが必要です",file=sys.stderr);return 1
    images=[Path(x).expanduser().resolve() for x in a.image]
    if any(not x.is_file() for x in images):print("指定画像が見つかりません",file=sys.stderr);return 1
    if a.mode=="voiceover" and images and not a.scene_map:print("画像を使う時は、Codexが実見して作った--scene-mapが必要です",file=sys.stderr);return 1
    scripts=Path(__file__).resolve().parent;transcript_dir=work/"transcript"
    try:
        if a.srt:
            segments=parse_srt(Path(a.srt).expanduser().resolve());transcript_dir.mkdir();transcript={"engine":"provided-srt","segments":segments,"review_required":False};(transcript_dir/"transcript.json").write_text(json.dumps(transcript,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        else:
            cmd=[sys.executable,str(scripts/"transcribe.py"),str(media),"--output-dir",str(transcript_dir),"--engine",a.engine,"--ffmpeg-dir",str(Path(ffmpeg).parent)]
            if a.model:cmd += ["--model",a.model]
            if a.runtime:cmd += ["--runtime",a.runtime]
            subprocess.run(cmd,check=True);transcript=json.loads((transcript_dir/"transcript.json").read_text(encoding="utf-8"));segments=transcript["segments"]
    except (RuntimeError,subprocess.CalledProcessError,OSError,json.JSONDecodeError) as e:print("字幕作成に失敗しました:",e,file=sys.stderr);return 1
    length=duration(ffprobe,media);render_length=round(length*30)/30;rows=[r for r in caption_rows(segments) if r["start"]<render_length]
    for r in rows:
        r["end"]=min(float(r["end"]),render_length)
        r.update({"font_size":76 if a.mode=="voiceover" else 72,"position":[540,1500]})
        if a.mode=="voiceover" and images:r.update({"box":True,"box_opacity":.46,"box_padding":18})
    if not rows:print("字幕を作れませんでした",file=sys.stderr);return 1
    inserts=[]
    if a.mode=="voiceover" and images:
        try:scenes=parse_scene_map(Path(a.scene_map).expanduser().resolve(),images,render_length)
        except RuntimeError as e:print("画像の対応表に問題があります:",e,file=sys.stderr);return 1
        for i,scene in enumerate(scenes):inserts.append({"type":"image","file":str(scene["image"]),"start":scene["start"],"end":scene["end"],"box":[0,0,1080,1920],"fit":"cover","zoom_from":1,"zoom_to":1.04+(i%2)*.015,"_speech":scene["speech"],"_reason":scene["reason"]})
    camera=[]
    if render_length>1:
        if a.mode=="talk":camera=[{"time":0,"zoom":1,"x":.5,"y":.42},{"time":render_length*.35,"zoom":1.04,"x":.5,"y":.42,"ease":"smooth"},{"time":render_length*.4,"zoom":1.16,"x":.5,"y":.42,"ease":"out"},{"time":render_length*.55,"zoom":1.16,"x":.5,"y":.42},{"time":render_length,"zoom":1,"x":.5,"y":.42,"ease":"smooth"}]
        else:camera=[{"time":0,"zoom":1,"x":.5,"y":.45},{"time":render_length,"zoom":1.04,"x":.5,"y":.45,"ease":"smooth"}]
    project={"mode":a.mode,"source":str(media),"font":fonts[0],"size":[1080,1920],"fps":30,"keep":[[0,length]],"tail":0,"voice_gain_db":0,"captions":rows,"inserts":inserts,"camera":camera,"output":"delivery/draft.mp4"}
    if background:project["background"]=str(background)
    project_path=work/"project.json";project_path.write_text(json.dumps(project,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    env=os.environ.copy();env["CODEX_VIDEO_FFMPEG_DIR"]=str(Path(ffmpeg).parent)
    try:
        subprocess.run([sys.executable,str(scripts/"render.py"),str(project_path),"--check"],check=True,env=env);subprocess.run([sys.executable,str(scripts/"render.py"),str(project_path)],check=True,env=env)
    except subprocess.CalledProcessError as e:print("書き出しに失敗しました:",e,file=sys.stderr);return 1
    report={"ok":True,"mode":a.mode,"transcript_engine":transcript.get("engine"),"review_required":transcript.get("review_required",True),"scene_map":str(Path(a.scene_map).expanduser().resolve()) if a.scene_map else None,"scene_count":len(inserts),"project":str(project_path),"output":str(work/"delivery"/"draft.mp4"),"note":"字幕の固有名詞、数字、区切りと、各画像の意味を音声と照合してから公開してください。"}
    (work/"auto-edit-report.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");print("下書きMP4まで作成しました:",report["output"]);print("字幕の人確認: 必要");return 0
if __name__=="__main__":raise SystemExit(main())
