#!/usr/bin/env python3
"""動画編集に必要なローカル環境を読み取りだけで確認する。"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import unicodedata
from pathlib import Path


def tool_path(name: str, explicit_dir: str | None, strict_path: bool) -> str | None:
    candidates: list[Path] = []
    if explicit_dir:
        candidates.append(Path(explicit_dir) / name)
    env_dir = os.environ.get("CODEX_VIDEO_FFMPEG_DIR")
    if env_dir:
        candidates.append(Path(env_dir) / name)
    if not strict_path:
        found = shutil.which(name)
        if found:
            candidates.append(Path(found))
        candidates.extend(
            [
                Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
                / "data"
                / "codex-video-starter"
                / "tools"
                / name,
                Path("/opt/homebrew/bin") / name,
                Path("/usr/local/bin") / name,
                Path.home() / ".local/bin" / name,
            ]
        )
    for item in candidates:
        if item.is_file() and os.access(item, os.X_OK):
            return str(item.resolve())
    return None


def font_candidates() -> list[str]:
    explicit = os.environ.get("CODEX_VIDEO_FONT")
    roots = [
        Path("/System/Library/Fonts"),
        Path("/Library/Fonts"),
        Path("C:/Windows/Fonts"),
        Path("/usr/share/fonts"),
        Path.home() / ".local/share/fonts",
    ]
    names = (
        "hiragino sans gb",
        "ヒラギノ",
        "notosanscjk",
        "notosansjp",
        "meiryo",
        "yugoth",
        "yugo",
        "ipa",
    )
    explicit_found: list[str] = []
    preferred: list[str] = []
    found: list[str] = []
    if explicit and Path(explicit).is_file():
        explicit_found.append(str(Path(explicit).resolve()))
    for root in roots:
        if not root.exists():
            continue
        for item in root.rglob("*"):
            if item.suffix.lower() not in {".ttf", ".ttc", ".otf"}:
                continue
            normalized = unicodedata.normalize("NFC", item.name).lower()
            if any(key in normalized for key in names):
                target = preferred if any(
                    mark in normalized
                    for mark in (" w8", " w9", "bold", "black", "heavy")
                ) else found
                target.append(str(item.resolve()))
    preferred.sort(key=lambda value: (" w8" not in unicodedata.normalize("NFC", Path(value).name).lower(), value))
    return list(dict.fromkeys(explicit_found + preferred + found))[:12]


def version_line(binary: str | None) -> str | None:
    if not binary:
        return None
    try:
        result = subprocess.run(
            [binary, "-version"], check=True, text=True, capture_output=True
        )
        return result.stdout.splitlines()[0]
    except (OSError, subprocess.CalledProcessError, IndexError):
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description="動画編集環境を確認します")
    parser.add_argument("--ffmpeg-dir", help="ffmpegとffprobeがあるフォルダ")
    parser.add_argument(
        "--strict-path",
        action="store_true",
        help="指定フォルダ以外を探さない。テスト用",
    )
    parser.add_argument("--json", action="store_true", help="JSONで表示")
    args = parser.parse_args()

    ffmpeg = tool_path("ffmpeg", args.ffmpeg_dir, args.strict_path)
    ffprobe = tool_path("ffprobe", args.ffmpeg_dir, args.strict_path)
    fonts = font_candidates()
    result = {
        "ok": bool(
            sys.version_info >= (3, 9) and ffmpeg and ffprobe and fonts
        ),
        "os": platform.platform(),
        "machine": platform.machine(),
        "python": platform.python_version(),
        "python_ok": sys.version_info >= (3, 9),
        "ffmpeg": ffmpeg,
        "ffmpeg_version": version_line(ffmpeg),
        "ffprobe": ffprobe,
        "ffprobe_version": version_line(ffprobe),
        "font": fonts[0] if fonts else None,
        "font_candidates": fonts,
        "network_used": False,
        "api_key_required": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("動画編集環境:", "利用できます" if result["ok"] else "不足があります")
        print("OS:", result["os"])
        print("Python:", result["python"], "OK" if result["python_ok"] else "3.9以上が必要")
        print("FFmpeg:", ffmpeg or "見つかりません")
        print("FFprobe:", ffprobe or "見つかりません")
        print("日本語フォント:", result["font"] or "見つかりません")
        if not ffmpeg or not ffprobe:
            print("公式案内: https://ffmpeg.org/download.html")
            if platform.system() == "Darwin" and platform.machine() == "arm64":
                print("このMacでは scripts/setup_tools.py --accept-download で専用フォルダへ導入できます")
        print("外部通信: なし / APIキー: 不要")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
