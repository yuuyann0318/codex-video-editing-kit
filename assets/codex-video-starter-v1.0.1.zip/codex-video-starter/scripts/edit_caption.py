#!/usr/bin/env python3
"""Codexが自然言語の修正依頼を反映する時に使う安全な字幕置換。"""

from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="字幕を1件だけ置き換えます")
    parser.add_argument("project")
    parser.add_argument("--from-text", required=True)
    parser.add_argument("--to-text", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--video-output", required=True)
    args = parser.parse_args()
    source = Path(args.project).expanduser().resolve()
    output = Path(args.output).expanduser().resolve()
    if output.exists():
        raise SystemExit(f"出力が既にあります: {output}")
    data = json.loads(source.read_text(encoding="utf-8"))
    matches = [row for row in data.get("captions", []) if row.get("text") == args.from_text]
    if len(matches) != 1:
        raise SystemExit(f"一致する字幕が1件ではありません: {len(matches)}件")
    matches[0]["text"] = args.to_text
    data["output"] = args.video_output
    output.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("新しい設定を作成しました:", output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
