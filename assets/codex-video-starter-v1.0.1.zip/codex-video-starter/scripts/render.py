#!/usr/bin/env python3
"""FFmpegだけで動く短尺縦動画レンダラー。Python追加パッケージは不要。"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import unicodedata
from pathlib import Path
from typing import Any


class RenderError(RuntimeError):
    pass


def run(command: list[Any], capture: bool = False) -> str:
    result = subprocess.run(
        [str(item) for item in command],
        check=True,
        text=True,
        capture_output=capture,
    )
    return result.stdout if capture else ""


def find_tool(name: str) -> str:
    explicit = os.environ.get("CODEX_VIDEO_FFMPEG_DIR")
    candidates = []
    if explicit:
        candidates.append(Path(explicit) / name)
    found = shutil.which(name)
    if found:
        candidates.append(Path(found))
    candidates.extend(
        [
            Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
            / "data"
            / "codex-video-starter"
            / "tools"
            / name,
            Path("/opt/homebrew/bin") / name,
            Path("/usr/local/bin") / name,
        ]
    )
    for item in candidates:
        if item.is_file() and os.access(item, os.X_OK):
            return str(item.resolve())
    raise RenderError(f"{name}が見つかりません。先にdoctor.pyを実行してください")


def resolve_path(root: Path, raw: str) -> Path:
    path = Path(raw).expanduser()
    return path.resolve() if path.is_absolute() else (root / path).resolve()


def probe(ffprobe: str, path: Path) -> dict[str, Any]:
    return json.loads(
        run(
            [
                ffprobe,
                "-v",
                "error",
                "-show_streams",
                "-show_format",
                "-of",
                "json",
                path,
            ],
            capture=True,
        )
    )


def media_duration(data: dict[str, Any]) -> float:
    try:
        return float(data["format"]["duration"])
    except (KeyError, TypeError, ValueError) as exc:
        raise RenderError("素材の長さを取得できません") from exc


def has_stream(data: dict[str, Any], kind: str) -> bool:
    return any(stream.get("codec_type") == kind for stream in data.get("streams", []))


def display_units(text: str) -> float:
    units = 0.0
    for char in text:
        if unicodedata.east_asian_width(char) in {"F", "W", "A"}:
            units += 1.0
        else:
            units += 0.55
    return units


def validate(cfg: dict[str, Any], root: Path, ffprobe: str) -> dict[str, Any]:
    mode = cfg.get("mode")
    if mode not in {"voiceover", "talk"}:
        raise RenderError("modeはvoiceoverまたはtalkです")
    source = resolve_path(root, cfg["source"])
    font = resolve_path(root, cfg["font"])
    if not source.is_file():
        raise RenderError(f"sourceが見つかりません: {source}")
    if not font.is_file():
        raise RenderError(f"fontが見つかりません: {font}")
    background = None
    if mode == "voiceover":
        background = resolve_path(root, cfg["background"])
        if not background.is_file():
            raise RenderError(f"backgroundが見つかりません: {background}")

    info = probe(ffprobe, source)
    if not has_stream(info, "audio"):
        raise RenderError("sourceに音声ストリームが必要です")
    if mode == "talk" and not has_stream(info, "video"):
        raise RenderError("talkのsourceには映像が必要です")

    fps = int(cfg.get("fps", 30))
    width, height = [int(value) for value in cfg.get("size", [1080, 1920])]
    if fps <= 0 or width <= 0 or height <= 0 or width % 2 or height % 2:
        raise RenderError("fpsと偶数のsizeを確認してください")

    keep = cfg.get("keep")
    if not isinstance(keep, list) or not keep:
        raise RenderError("keepが空です")
    parsed_keep: list[tuple[float, float]] = []
    last_end = -1.0
    for row in keep:
        if not isinstance(row, list) or len(row) != 2:
            raise RenderError("keepは[[開始,終了], ...]です")
        start, end = float(row[0]), float(row[1])
        if not (0 <= start < end) or start < last_end:
            raise RenderError("keepが重複、逆順、または不正です")
        parsed_keep.append((start, end))
        last_end = end
    if last_end > media_duration(info) + 0.05:
        raise RenderError("keepがsourceの長さを超えています")

    tail = float(cfg.get("tail", 0))
    if tail < 0:
        raise RenderError("tailは0以上です")
    duration = sum(end - start for start, end in parsed_keep) + tail
    frames = round(duration * fps)
    duration = frames / fps

    captions = cfg.get("captions", [])
    inserts = cfg.get("inserts", [])
    for label, rows in (("captions", captions), ("inserts", inserts)):
        if not isinstance(rows, list):
            raise RenderError(f"{label}は配列です")
        previous_end = 0
        for row in rows:
            start = round(float(row["start"]) * fps)
            end = round(float(row["end"]) * fps)
            if not (0 <= start < end <= frames) or start < previous_end:
                raise RenderError(f"{label}が重複、逆順、または動画外です")
            previous_end = end

    for index, caption in enumerate(captions):
        text = str(caption["text"])
        lines = text.split("\n")
        if len(lines) > 1 and not caption.get("allow_two_lines", False):
            raise RenderError("本文字幕は1行です。2行はallow_two_linesを指定してください")
        if len(lines) > 2:
            raise RenderError("字幕は最大2行です")
        size = int(caption.get("font_size", 76))
        for line in lines:
            estimated = display_units(line) * size
            if estimated > width - 80:
                raise RenderError(
                    f"字幕{index + 1}が長すぎます。自然な句で分けてください: {line}"
                )

    resolved_inserts: list[dict[str, Any]] = []
    for row in inserts:
        item = dict(row)
        if item.get("type") not in {"image", "video"}:
            raise RenderError("insertのtypeはimageまたはvideoです")
        fit = item.get("fit", "contain")
        if fit not in {"contain", "cover"}:
            raise RenderError("insertのfitはcontainまたはcoverです")
        zoom_from = float(item.get("zoom_from", 1))
        zoom_to = float(item.get("zoom_to", zoom_from))
        if not 1 <= zoom_from <= 1.2 or not 1 <= zoom_to <= 1.2:
            raise RenderError("insertのzoom_fromとzoom_toは1〜1.2です")
        path = resolve_path(root, item["file"])
        if not path.is_file():
            raise RenderError(f"insertが見つかりません: {path}")
        box = [int(value) for value in item["box"]]
        if len(box) != 4:
            raise RenderError("insertのboxは[左,上,幅,高さ]です")
        x, y, box_width, box_height = box
        if min(x, y) < 0 or min(box_width, box_height) <= 0:
            raise RenderError("insertのboxが不正です")
        if x + box_width > width or y + box_height > height:
            raise RenderError("insertが画面外です")
        if item["type"] == "video":
            speed = float(item.get("speed", 1))
            source_start = float(item.get("source_start", 0))
            need = (float(item["end"]) - float(item["start"])) * speed
            if speed <= 0 or source_start + need > media_duration(probe(ffprobe, path)) + 0.05:
                raise RenderError("動画insertの長さが足りません")
        item["_path"] = path
        item["_box"] = box
        item["_fit"] = fit
        item["_zoom_from"] = zoom_from
        item["_zoom_to"] = zoom_to
        resolved_inserts.append(item)

    camera = cfg.get("camera", [])
    last_time = -1.0
    for key in camera:
        time = float(key["time"])
        zoom = float(key["zoom"])
        x = float(key.get("x", 0.5))
        y = float(key.get("y", 0.5))
        if not (last_time < time <= duration and 1 <= zoom <= 3 and 0 <= x <= 1 and 0 <= y <= 1):
            raise RenderError("cameraの時刻、倍率、中心を確認してください")
        last_time = time
    if camera and float(camera[0]["time"]) != 0:
        raise RenderError("cameraの最初の時刻は0です")

    disclosure = str(cfg.get("disclosure", "")).strip()
    if "\n" in disclosure or display_units(disclosure) > 40:
        raise RenderError("注記は1行40文字相当以内です")
    output = resolve_path(root, cfg.get("output", "delivery/video.mp4"))
    protected_inputs = {source, font}
    if background is not None:
        protected_inputs.add(background)
    protected_inputs.update(item["_path"] for item in resolved_inserts)
    for item in cfg.get("sfx", []):
        if "file" in item:
            protected_inputs.add(resolve_path(root, item["file"]))
    if output in protected_inputs:
        raise RenderError("出力先を入力素材と同じファイルにはできません")
    return {
        "mode": mode,
        "source": source,
        "background": background,
        "font": font,
        "fps": fps,
        "width": width,
        "height": height,
        "keep": parsed_keep,
        "tail": tail,
        "duration": duration,
        "frames": frames,
        "captions": captions,
        "inserts": resolved_inserts,
        "camera": camera,
        "sfx": cfg.get("sfx", []),
        "voice_gain_db": float(cfg.get("voice_gain_db", 0)),
        "disclosure": disclosure,
        "output": output,
    }


def camera_expression(camera: list[dict[str, Any]], field: str, default: float, fps: int) -> str:
    expression = str(float(camera[-1].get(field, default)))
    for left, right in reversed(list(zip(camera, camera[1:]))):
        start = round(float(left["time"]) * fps)
        end = round(float(right["time"]) * fps)
        if end <= start:
            raise RenderError("cameraのキーが同じフレームにあります")
        progress = f"max(0,min(1,(on-{start})/{end - start}))"
        ease = right.get("ease")
        if ease == "smooth":
            progress = f"({progress})*({progress})*(3-2*({progress}))"
        elif ease == "out":
            progress = f"(1-pow(1-({progress}),3))"
        elif ease not in {None, "linear"}:
            raise RenderError("cameraのeaseはlinear、smooth、outです")
        start_value = float(left.get(field, default))
        end_value = float(right.get(field, default))
        expression = (
            f"if(lt(on,{end}),{start_value}+({end_value - start_value})*"
            f"({progress}),{expression})"
        )
    return expression


def write_voice(ffmpeg: str, data: dict[str, Any], target: Path) -> None:
    filters = []
    labels = []
    for index, (start, end) in enumerate(data["keep"]):
        filters.append(
            f"[0:a]atrim=start={start}:end={end},asetpts=PTS-STARTPTS[a{index}]"
        )
        labels.append(f"[a{index}]")
    filters.append(
        "".join(labels)
        + f"concat=n={len(labels)}:v=0:a=1,volume={data['voice_gain_db']}dB,"
        + f"apad=pad_dur={data['tail'] + 0.2},atrim=duration={data['duration']}[voice]"
    )
    run(
        [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-i",
            data["source"],
            "-filter_complex",
            ";".join(filters),
            "-map",
            "[voice]",
            "-ar",
            "48000",
            "-ac",
            "1",
            target,
        ]
    )


def write_base(ffmpeg: str, data: dict[str, Any], target: Path) -> None:
    width, height, fps = data["width"], data["height"], data["fps"]
    if data["mode"] == "talk":
        filters = []
        labels = []
        for index, (start, end) in enumerate(data["keep"]):
            filters.append(
                f"[0:v]trim=start={start}:end={end},setpts=PTS-STARTPTS[v{index}]"
            )
            labels.append(f"[v{index}]")
        filters.append(
            "".join(labels)
            + f"concat=n={len(labels)}:v=1:a=0,fps={fps},"
            + f"scale={width}:{height}:force_original_aspect_ratio=increase,"
            + f"crop={width}:{height},setsar=1,tpad=stop_mode=clone:stop_duration={data['tail'] + 0.2}[base]"
        )
        command = [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-i",
            data["source"],
            "-filter_complex",
            ";".join(filters),
            "-map",
            "[base]",
        ]
    else:
        command = [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-stream_loop",
            "-1",
            "-i",
            data["background"],
            "-vf",
            f"fps={fps},scale={width}:{height}:force_original_aspect_ratio=increase,"
            f"crop={width}:{height},setsar=1",
        ]
    run(
        command
        + [
            "-an",
            "-t",
            data["duration"],
            "-c:v",
            "libx264",
            "-preset",
            "fast",
            "-crf",
            "18",
            "-pix_fmt",
            "yuv420p",
            target,
        ]
    )


def write_composite(
    ffmpeg: str, data: dict[str, Any], base: Path, target: Path, work: Path
) -> None:
    command: list[Any] = [ffmpeg, "-v", "error", "-y", "-i", base]
    filters: list[str] = []
    current = "0:v"
    input_index = 1

    camera = data["camera"]
    if camera:
        zoom = camera_expression(camera, "zoom", 1, data["fps"])
        center_x = camera_expression(camera, "x", 0.5, data["fps"])
        center_y = camera_expression(camera, "y", 0.5, data["fps"])
        filters.append(
            f"[0:v]zoompan=z='{zoom}':"
            f"x='max(0,min(iw-iw/zoom,iw*({center_x})-iw/zoom/2))':"
            f"y='max(0,min(ih-ih/zoom,ih*({center_y})-ih/zoom/2))':"
            f"d=1:s={data['width']}x{data['height']}:fps={data['fps']}[camera]"
        )
        current = "camera"

    for index, item in enumerate(data["inserts"]):
        start = float(item["start"])
        end = float(item["end"])
        x, y, width, height = item["_box"]
        if item["type"] == "image":
            command += ["-loop", "1", "-framerate", data["fps"], "-i", item["_path"]]
            if item["_fit"] == "cover":
                image_filter = (
                    f"[{input_index}:v]scale={width}:{height}:force_original_aspect_ratio=increase,"
                    f"crop={width}:{height},setsar=1"
                )
                if item["_zoom_from"] != 1 or item["_zoom_to"] != 1:
                    start_frame = round(start * data["fps"])
                    duration_frames = max(1, round((end - start) * data["fps"]))
                    zoom_delta = item["_zoom_to"] - item["_zoom_from"]
                    image_filter += (
                        f",zoompan=z='{item['_zoom_from']}+{zoom_delta}*max(0,min(1,(on-{start_frame})/{duration_frames}))':"
                        f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:"
                        f"s={width}x{height}:fps={data['fps']}"
                    )
                filters.append(image_filter + f"[insert{index}]")
            else:
                filters.append(
                    f"[{input_index}:v]scale={width}:{height}:force_original_aspect_ratio=decrease,"
                    f"setsar=1[insert{index}]"
                )
        else:
            command += ["-i", item["_path"]]
            speed = float(item.get("speed", 1))
            source_start = float(item.get("source_start", 0))
            filters.append(
                f"[{input_index}:v]trim=start={source_start}:duration={(end-start)*speed},"
                f"setpts=(PTS-STARTPTS)/{speed}+{start}/TB,fps={data['fps']},"
                f"scale={width}:{height}:force_original_aspect_ratio=decrease,setsar=1[insert{index}]"
            )
        filters.append(
            f"[{current}][insert{index}]overlay=x={x}+({width}-overlay_w)/2:y={y}+"
            f"({height}-overlay_h)/2:eof_action=pass:enable='gte(t,{start})*lt(t,{end})'[layer{index}]"
        )
        current = f"layer{index}"
        input_index += 1

    for index, caption in enumerate(data["captions"]):
        text_file = work / f"caption-{index:03}.txt"
        text_file.write_text(str(caption["text"]), encoding="utf-8")
        font_size = int(caption.get("font_size", 76))
        x = int(caption.get("position", [data["width"] // 2, 670])[0])
        y = int(caption.get("position", [data["width"] // 2, 670])[1])
        start = float(caption["start"])
        end = float(caption["end"])
        escaped_text = str(text_file).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        escaped_font = str(data["font"]).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        box_style = ""
        if caption.get("box", False):
            box_style = (
                f"box=1:boxcolor=black@{float(caption.get('box_opacity', 0.48))}:"
                f"boxborderw={int(caption.get('box_padding', 18))}:"
            )
        filters.append(
            f"[{current}]drawtext=fontfile='{escaped_font}':textfile='{escaped_text}':"
            f"reload=0:fontsize={font_size}:fontcolor=white:{box_style}shadowcolor=black@0.95:"
            f"shadowx=3:shadowy=7:line_spacing={int(caption.get('line_gap', 24))}:"
            f"x={x}-text_w/2:y={y}-text_h/2:enable='gte(t,{start})*lt(t,{end})'[caption{index}]"
        )
        current = f"caption{index}"

    if data["disclosure"]:
        disclosure_file = work / "disclosure.txt"
        disclosure_file.write_text(data["disclosure"], encoding="utf-8")
        escaped_text = str(disclosure_file).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        escaped_font = str(data["font"]).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")
        filters.append(
            f"[{current}]drawtext=fontfile='{escaped_font}':textfile='{escaped_text}':"
            f"fontsize=30:fontcolor=white@0.85:box=1:boxcolor=black@0.45:boxborderw=10:"
            f"x=w-text_w-38:y=h-text_h-38[disclosure]"
        )
        current = "disclosure"

    if filters:
        command += ["-filter_complex", ";".join(filters), "-map", f"[{current}]"]
    else:
        command += ["-map", "0:v"]
    run(
        command
        + [
            "-an",
            "-t",
            data["duration"],
            "-c:v",
            "libx264",
            "-preset",
            "fast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            target,
        ]
    )


def mix_audio(ffmpeg: str, data: dict[str, Any], voice: Path, target: Path, root: Path) -> None:
    sfx = data["sfx"]
    if not sfx:
        shutil.copy2(voice, target)
        return
    command: list[Any] = [ffmpeg, "-v", "error", "-y", "-i", voice]
    filters = ["[0:a]asetpts=PTS-STARTPTS[voice]"]
    labels = ["[voice]"]
    for index, item in enumerate(sfx, start=1):
        path = resolve_path(root, item["file"])
        if not path.is_file():
            raise RenderError(f"効果音が見つかりません: {path}")
        time_ms = round(float(item["time"]) * 1000)
        if not 0 <= float(item["time"]) < data["duration"]:
            raise RenderError("効果音の時刻が動画外です")
        command += ["-i", path]
        filters.append(
            f"[{index}:a]atrim=duration={float(item.get('duration', 0.7))},"
            f"asetpts=PTS-STARTPTS,volume={float(item.get('gain_db', -18))}dB,"
            f"adelay={time_ms}:all=1[sfx{index}]"
        )
        labels.append(f"[sfx{index}]")
    filters.append(
        "".join(labels)
        + f"amix=inputs={len(labels)}:normalize=0:duration=first,alimiter=limit=0.95[mix]"
    )
    run(
        command
        + [
            "-filter_complex",
            ";".join(filters),
            "-map",
            "[mix]",
            "-ar",
            "48000",
            "-ac",
            "1",
            target,
        ]
    )


def render(project: Path, check_only: bool, overwrite: bool) -> Path:
    if not project.is_file():
        raise RenderError(f"project.jsonが見つかりません: {project}")
    try:
        cfg = json.loads(project.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RenderError(f"project.jsonを読めません: {exc}") from exc
    ffmpeg = find_tool("ffmpeg")
    ffprobe = find_tool("ffprobe")
    data = validate(cfg, project.parent, ffprobe)
    output = data["output"]
    if output.exists() and not overwrite:
        raise RenderError("出力が既にあります。新しい名前を使ってください")
    print(
        "入力確認:",
        data["mode"],
        f"{data['duration']:.3f}秒",
        f"字幕{len(data['captions'])}件",
        f"挿入{len(data['inserts'])}件",
    )
    if check_only:
        return output

    output.parent.mkdir(parents=True, exist_ok=True)
    work = output.parent / f"{output.stem}-work"
    if work.exists():
        raise RenderError(f"作業フォルダが既にあります: {work}")
    work.mkdir(parents=True)
    voice = work / "voice.wav"
    mixed = work / "mixed.wav"
    base = work / "base.mp4"
    composite = work / "composite.mp4"
    write_voice(ffmpeg, data, voice)
    mix_audio(ffmpeg, data, voice, mixed, project.parent)
    write_base(ffmpeg, data, base)
    write_composite(ffmpeg, data, base, composite, work)
    run(
        [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-i",
            composite,
            "-i",
            mixed,
            "-map",
            "0:v",
            "-map",
            "1:a",
            "-t",
            data["duration"],
            "-c:v",
            "copy",
            "-c:a",
            "aac",
            "-b:a",
            "192k",
            "-movflags",
            "+faststart",
            output,
        ]
    )
    run([ffmpeg, "-v", "error", "-i", output, "-f", "null", "-"])
    report = {
        "mode": data["mode"],
        "duration": data["duration"],
        "frames": data["frames"],
        "size": [data["width"], data["height"]],
        "fps": data["fps"],
        "captions": len(data["captions"]),
        "inserts": len(data["inserts"]),
        "source_preserved": True,
        "output": str(output),
    }
    (work / "render-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("書き出しと全体デコード完了:", output)
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="短い縦動画をMP4へ書き出します")
    parser.add_argument("project", help="project.json")
    parser.add_argument("--check", action="store_true", help="入力確認だけ")
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="テスト専用。通常は新しい出力名を使ってください",
    )
    args = parser.parse_args()
    try:
        render(Path(args.project).expanduser().resolve(), args.check, args.overwrite)
        return 0
    except (RenderError, KeyError, ValueError, subprocess.CalledProcessError) as exc:
        print("エラー:", exc, file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
