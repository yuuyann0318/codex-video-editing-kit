#!/usr/bin/env python3
"""権利根拠を記録した同梱素材だけで2モードの練習動画を作る。"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from doctor import font_candidates, tool_path


def run(command: list[object]) -> None:
    subprocess.run([str(item) for item in command], check=True)


def create_assets(ffmpeg: str, out: Path, skill: Path) -> None:
    assets = out / "assets"
    assets.mkdir(parents=True)
    image_names = [
        "practice-01.png",
        "practice-02.png",
        "practice-03.png",
        "sample-cafe.png",
        "sample-focaccia-breakfast.png",
    ]
    for name in image_names:
        source = skill / "sample" / "assets" / name
        if not source.is_file():
            raise RuntimeError(f"練習画像が見つかりません: {source}")
        shutil.copy2(source, assets / source.name)

    voice = skill / "sample" / "assets" / "practice-ja.wav"
    if not voice.is_file():
        raise RuntimeError(f"練習音声が見つかりません: {voice}")
    shutil.copy2(voice, assets / "practice-ja.wav")
    run(
        [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=c=#10243d:s=1080x1920:r=30:d=5.875",
            "-vf",
            "drawbox=x=0:y=0:w=iw:h=ih:color=#173d5f@0.35:t=fill,"
            "drawbox=x=80:y=110:w=920:h=1680:color=#0d263f@0.45:t=fill",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            assets / "background.mp4",
        ]
    )
    pulse = "if(lt(mod(t\\,2)\\,0.15)\\,0.12*sin(2*PI*660*t)\\,0)"
    flash = (
        "drawbox=x=200:y=500:w=680:h=680:color=#35d4c7@0.65:t=fill:"
        "enable='lt(mod(t,2),0.15)',"
        "drawbox=x=270:y=570:w=540:h=540:color=#10243d@0.85:t=fill"
    )
    run(
        [
            ffmpeg,
            "-v",
            "error",
            "-y",
            "-f",
            "lavfi",
            "-i",
            "color=c=#25486b:s=1080x1920:r=30:d=6.5",
            "-f",
            "lavfi",
            "-i",
            f"aevalsrc={pulse}:s=48000:d=6.5",
            "-vf",
            flash,
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-c:a",
            "aac",
            "-shortest",
            assets / "talk-sync-fixture.mp4",
        ]
    )


def prepare_project(skill: Path, out: Path, mode: str, font: str) -> Path:
    source = skill / "templates" / f"{mode}.project.json"
    data = json.loads(source.read_text(encoding="utf-8"))
    data["font"] = font
    project = out / f"{mode}.project.json"
    project.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return project


def main() -> int:
    parser = argparse.ArgumentParser(description="同梱素材で練習動画を作ります")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--all", action="store_true", help="2モードを作る")
    group.add_argument("--mode", choices=["voiceover", "talk"], help="1モードだけ作る")
    parser.add_argument("--out", help="空の出力フォルダ。省略時は一時フォルダ")
    parser.add_argument("--ffmpeg-dir", help="ffmpegとffprobeがあるフォルダ")
    args = parser.parse_args()

    ffmpeg = tool_path("ffmpeg", args.ffmpeg_dir, False)
    ffprobe = tool_path("ffprobe", args.ffmpeg_dir, False)
    fonts = font_candidates()
    if not ffmpeg or not ffprobe or not fonts:
        print("環境が不足しています。先にdoctor.pyを実行してください", file=sys.stderr)
        return 1
    out = (
        Path(args.out).expanduser().resolve()
        if args.out
        else Path(tempfile.mkdtemp(prefix="codex-video-demo-"))
    )
    if out.exists() and any(out.iterdir()):
        print(f"出力先が空ではありません: {out}", file=sys.stderr)
        return 1
    out.mkdir(parents=True, exist_ok=True)
    skill = Path(__file__).resolve().parent.parent
    create_assets(ffmpeg, out, skill)
    modes = ["voiceover", "talk"] if args.all else [args.mode]
    outputs = []
    env = os.environ.copy()
    env["CODEX_VIDEO_FFMPEG_DIR"] = str(Path(ffmpeg).parent)
    for mode in modes:
        project = prepare_project(skill, out, mode, fonts[0])
        subprocess.run(
            [sys.executable, str(skill / "scripts" / "render.py"), str(project), "--check"],
            check=True,
            env=env,
        )
        subprocess.run(
            [sys.executable, str(skill / "scripts" / "render.py"), str(project)],
            check=True,
            env=env,
        )
        video = out / "delivery" / f"{mode}-demo.mp4"
        preview = out / "delivery" / f"{mode}-preview.png"
        run([ffmpeg, "-v", "error", "-y", "-ss", "3", "-i", video, "-frames:v", "1", preview])
        outputs.append({"mode": mode, "video": str(video), "preview": str(preview)})
    report = {
        "ok": True,
        "outputs": outputs,
        "voiceover_audio": "sample/assets/practice-ja.wav",
        "voiceover_audio_license": "CC BY 4.0; attribution is in sample/THIRD_PARTY_NOTICES.md",
        "voiceover_expected_text": "カフェとは、ブレックファストとして、フォカッチャを食べれる場所でもある。",
        "voiceover_visual_sequence": ["cafe and breakfast", "focaccia close-up"],
        "generated_image_disclosure": "shown in the video",
        "talk_fixture": "visual flash and synchronized test tone",
        "real_speaker_lip_sync": "not tested",
        "network_used": False,
        "api_key_required": False,
    }
    (out / "demo-report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print("練習動画を作成しました:", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
