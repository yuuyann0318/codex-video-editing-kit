#!/usr/bin/env python3
"""ローカル音声認識を専用venvへ導入する。システムPythonは変更しない。"""
from __future__ import annotations
import argparse, json, os, platform, shutil, subprocess, sys, tempfile, venv
from pathlib import Path

PYPI_INDEX = "https://pypi.org/simple"
PIP_BOOTSTRAP = "pip==25.1.1"

def default_runtime() -> Path:
    base = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    return base / "data" / "codex-video-starter" / "stt"

def rewrite_venv_paths(staging:Path,runtime:Path)->None:
    old=str(staging).encode();new=str(runtime).encode()
    bindir=staging/("Scripts" if os.name=="nt" else "bin")
    for item in bindir.iterdir():
        if not item.is_file() or item.stat().st_size>1024*1024:continue
        try:data=item.read_bytes()
        except OSError:continue
        if old in data:item.write_bytes(data.replace(old,new))

def summarize_pip_report(report_path:Path)->list[dict[str,str]]:
    report=json.loads(report_path.read_text(encoding="utf-8"))
    resolved=[]
    for item in report.get("install",[]):
        metadata=item.get("metadata",{})
        download=item.get("download_info",{})
        resolved.append({
            "name":str(metadata.get("name","")),
            "version":str(metadata.get("version","")),
            "download_url":str(download.get("url","")),
        })
    return resolved

def main() -> int:
    p=argparse.ArgumentParser(description="音声認識を専用環境へ導入します")
    p.add_argument("--runtime");p.add_argument("--engine",choices=["auto","mlx","faster"],default="auto")
    p.add_argument("--accept-download",action="store_true",help="PyPIから無料パッケージを取得することを確認")
    a=p.parse_args()
    if not a.accept_download:
        print("外部取得を行うため --accept-download が必要です",file=sys.stderr);return 1
    runtime=Path(a.runtime).expanduser().resolve() if a.runtime else default_runtime()
    if runtime.exists() and any(runtime.iterdir()):
        print(f"保存先が空ではありません: {runtime}",file=sys.stderr);return 1
    runtime.parent.mkdir(parents=True,exist_ok=True)
    engine=a.engine
    if engine=="auto": engine="mlx" if platform.system()=="Darwin" and platform.machine()=="arm64" else "faster"
    package="mlx-whisper==0.4.3" if engine=="mlx" else "faster-whisper==1.2.0"
    print("取得を開始します:",package,flush=True)
    print("回線により時間がかかります。途中停止時は未完成の専用環境を除き、pipの取得cacheは再試行に使われます",flush=True)
    staging=Path(tempfile.mkdtemp(prefix=".codex-video-stt-",dir=str(runtime.parent)))
    try:
        venv.EnvBuilder(with_pip=True).create(staging)
        python=staging/("Scripts/python.exe" if os.name=="nt" else "bin/python")
        subprocess.run([
            str(python),"-m","pip","install","--upgrade",
            "--index-url",PYPI_INDEX,PIP_BOOTSTRAP,
        ],check=True)
        pip_report=staging/"pip-install-report.json"
        subprocess.run([
            str(python),"-m","pip","install","--upgrade",
            "--index-url",PYPI_INDEX,"--report",str(pip_report),package,
        ],check=True)
        resolved=summarize_pip_report(pip_report)
        rewrite_venv_paths(staging,runtime)
        record={
            "engine":engine,
            "package":package,
            "configured_index":PYPI_INDEX,
            "pip_bootstrap":{
                "package":PIP_BOOTSTRAP,
                "configured_index":PYPI_INDEX,
                "download_url":"not captured: the bundled pip predates --report",
            },
            "pip_report":"pip-install-report.json",
            "resolved_packages":resolved,
            "model_download":"first transcription only",
        }
        (staging/"install-record.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
        os.replace(staging,runtime);staging=None
        print("音声認識の専用環境を作成しました:",runtime)
        print("engine:",engine)
        print("モデル本体は最初の文字起こし時に取得されます")
        if engine=="mlx":print("既定の高品質モデル実測: 約1.5GB。処理時間は音声長と端末性能で変わります")
        return 0
    except (OSError,subprocess.CalledProcessError) as e:
        print("音声認識環境の作成に失敗しました:",e,file=sys.stderr);return 1
    finally:
        if staging is not None and staging.exists():shutil.rmtree(staging)
if __name__=="__main__": raise SystemExit(main())
