#!/usr/bin/env python3
"""FFmpegとFFprobeをキット専用フォルダへ検証付きで導入する。"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath


PROVIDER = "Martin Riedl's FFmpeg Build Server"
PROVIDER_PAGE = "https://ffmpeg.martin-riedl.de/"
FFMPEG_PROJECT_DOWNLOAD = "https://ffmpeg.org/download.html"
MAC_ARM64_RELEASE = {
    "version": "9.0.2",
    "ffmpeg": {
        "url": "https://ffmpeg.martin-riedl.de/download/macos/arm64/1789931890_9.0.2/ffmpeg.zip",
        "sha256": "c8ed4c4e6978a03c485edbfe4e0a5dc2380f8a30bba5150531b31b094492d924",
    },
    "ffprobe": {
        "url": "https://ffmpeg.martin-riedl.de/download/macos/arm64/1789931890_9.0.2/ffprobe.zip",
        "sha256": "fcbe839537485eaee7a7a8bc5cbc0f90d53617e80943e8a5b2e31cb851197ea6",
    },
}


class SetupError(RuntimeError):
    pass


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def default_destination() -> Path:
    base = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
    return base / "data" / "codex-video-starter" / "tools"


def download(url: str, target: Path) -> None:
    request = urllib.request.Request(url, headers={"User-Agent": "codex-video-starter/1.0"})
    with urllib.request.urlopen(request, timeout=60) as source, target.open("wb") as output:
        shutil.copyfileobj(source, output)


def extract_single(archive: Path, expected_name: str, target: Path) -> None:
    try:
        with zipfile.ZipFile(archive) as bundle:
            files = [item for item in bundle.infolist() if not item.is_dir()]
            if len(files) != 1:
                raise SetupError(f"{expected_name}のZIP内容が想定と違います")
            info = files[0]
            name = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            if (
                name.is_absolute()
                or ".." in name.parts
                or name.name != expected_name
                or mode == stat.S_IFLNK
                or info.file_size > 200 * 1024 * 1024
            ):
                raise SetupError(f"{expected_name}のZIP内パスまたは形式が不正です")
            with bundle.open(info) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)
            target.chmod(0o755)
    except (OSError, zipfile.BadZipFile) as exc:
        raise SetupError(f"{expected_name}のZIPを展開できません: {exc}") from exc


def version(binary: Path) -> str:
    result = subprocess.run(
        [str(binary), "-version"], check=True, text=True, capture_output=True
    )
    return result.stdout.splitlines()[0]


def main() -> int:
    parser = argparse.ArgumentParser(description="動画書き出し道具を専用フォルダへ導入します")
    parser.add_argument("--destination", help="空の導入先。省略時はCodex専用データ領域")
    parser.add_argument(
        "--accept-download", action="store_true", help="記載元から無料バイナリを取得することを確認"
    )
    args = parser.parse_args()
    if not args.accept_download:
        print("外部取得を行うため --accept-download が必要です", file=sys.stderr)
        return 1
    if not (platform.system() == "Darwin" and platform.machine() == "arm64"):
        print("自動導入を実機確認したのはApple SiliconのMacだけです", file=sys.stderr)
        print("公式案内:", FFMPEG_PROJECT_DOWNLOAD, file=sys.stderr)
        return 1
    destination = (
        Path(args.destination).expanduser().resolve()
        if args.destination
        else default_destination().resolve()
    )
    if destination.exists() and any(destination.iterdir()):
        print(f"導入先が空ではありません: {destination}", file=sys.stderr)
        return 1
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".codex-video-tools-", dir=str(destination.parent)))
    downloads = staging / "downloads"
    unpacked = staging / "bin"
    downloads.mkdir()
    unpacked.mkdir()
    try:
        records = {}
        for name in ("ffmpeg", "ffprobe"):
            item = MAC_ARM64_RELEASE[name]
            archive = downloads / f"{name}.zip"
            print("取得中:", name, "配布元:", PROVIDER_PAGE, flush=True)
            download(item["url"], archive)
            actual = digest(archive)
            if actual != item["sha256"]:
                raise SetupError(f"{name}の配布SHA-256が一致しません")
            binary = unpacked / name
            extract_single(archive, name, binary)
            print("SHA-256検査と実行確認:", name, "合格", flush=True)
            records[name] = {
                "url": item["url"],
                "archive_sha256": actual,
                "binary_sha256": digest(binary),
                "version": version(binary),
            }
        record = {
            "provider": PROVIDER,
            "provider_page": PROVIDER_PAGE,
            "ffmpeg_project_download": FFMPEG_PROJECT_DOWNLOAD,
            "release": MAC_ARM64_RELEASE["version"],
            "platform": "macOS arm64",
            "files": records,
        }
        (unpacked / "install-record.json").write_text(
            json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
        os.replace(unpacked, destination)
        print("専用フォルダへ導入しました:", destination)
        print("配布元・SHA-256記録:", destination / "install-record.json")
        return 0
    except (SetupError, OSError, subprocess.CalledProcessError) as exc:
        print("導入を停止しました:", exc, file=sys.stderr)
        return 1
    finally:
        if staging.exists():
            shutil.rmtree(staging)


if __name__ == "__main__":
    raise SystemExit(main())
