#!/usr/bin/env python3
"""APIキー不要のローカル音声認識を共通JSONとSRTへ変換する。"""
from __future__ import annotations
import argparse,json,os,platform,shutil,subprocess,sys
from pathlib import Path
from doctor import tool_path

def default_runtime()->Path:
    return Path(os.environ.get("CODEX_HOME",Path.home()/".codex"))/"data"/"codex-video-starter"/"stt"
def stamp(seconds:float)->str:
    ms=max(0,round(seconds*1000));h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f"{h:02}:{m:02}:{s:02},{ms:03}"
def write_srt(path:Path,segments:list[dict])->None:
    lines=[]
    for i,s in enumerate(segments,1): lines += [str(i),f"{stamp(float(s['start']))} --> {stamp(float(s['end']))}",str(s['text']).strip(),""]
    path.write_text("\n".join(lines),encoding="utf-8")
def mlx_cli(runtime:Path)->str|None:
    isolated=next((str(p) for p in [runtime/"bin/mlx_whisper",runtime/"Scripts/mlx_whisper.exe"] if p.is_file()),None)
    if isolated:return isolated
    return shutil.which("mlx_whisper")
def runtime_python(runtime:Path)->Path:return runtime/("Scripts/python.exe" if os.name=="nt" else "bin/python")
def transcribe_mlx(media:Path,out:Path,model:str,language:str,ffmpeg_dir:Path,runtime:Path)->dict:
    cli=mlx_cli(runtime)
    if not cli: raise RuntimeError("mlx-whisperが見つかりません。setup_stt.pyを実行してください")
    raw_dir=out/".mlx-output";raw_dir.mkdir();env=os.environ.copy();env["PATH"]=str(ffmpeg_dir)+os.pathsep+env.get("PATH","")
    subprocess.run([cli,str(media),"--model",model,"--output-dir",str(raw_dir),"--output-format","json","--language",language,"--word-timestamps","True","--verbose","False"],check=True,env=env)
    return json.loads((raw_dir/f"{media.stem}.json").read_text(encoding="utf-8"))
def transcribe_faster(media:Path,out:Path,model:str,language:str,runtime:Path)->dict:
    python=runtime_python(runtime)
    if not python.is_file():raise RuntimeError("faster-whisperの専用環境がありません。setup_stt.pyを実行してください")
    raw=out/".faster-output.json";worker=Path(__file__).with_name("_faster_worker.py")
    subprocess.run([str(python),str(worker),str(media),"--model",model,"--language",language,"--output",str(raw)],check=True)
    return json.loads(raw.read_text(encoding="utf-8"))
def main()->int:
    p=argparse.ArgumentParser(description="音声をローカルで文字起こしします");p.add_argument("media");p.add_argument("--output-dir",required=True);p.add_argument("--engine",choices=["auto","mlx","faster"],default="auto");p.add_argument("--model");p.add_argument("--language",default="ja");p.add_argument("--runtime");p.add_argument("--ffmpeg-dir");a=p.parse_args()
    media=Path(a.media).expanduser().resolve();out=Path(a.output_dir).expanduser().resolve();runtime=Path(a.runtime).expanduser().resolve() if a.runtime else default_runtime()
    if not media.is_file():print(f"素材が見つかりません: {media}",file=sys.stderr);return 1
    if out.exists() and any(out.iterdir()):print(f"出力先が空ではありません: {out}",file=sys.stderr);return 1
    out.mkdir(parents=True,exist_ok=True);ffmpeg=tool_path("ffmpeg",a.ffmpeg_dir,False);ffprobe=tool_path("ffprobe",a.ffmpeg_dir,False)
    if not ffmpeg or not ffprobe:print("FFmpegとFFprobeが必要です",file=sys.stderr);return 1
    engine=a.engine
    if engine=="auto": engine="mlx" if platform.system()=="Darwin" and platform.machine()=="arm64" and mlx_cli(runtime) else "faster"
    try:
        if engine=="mlx":model=a.model or "mlx-community/whisper-large-v3-turbo";raw=transcribe_mlx(media,out,model,a.language,Path(ffmpeg).parent,runtime);engine_name="mlx-whisper"
        else:model=a.model or "small";raw=transcribe_faster(media,out,model,a.language,runtime);engine_name="faster-whisper"
    except (RuntimeError,subprocess.CalledProcessError,OSError,json.JSONDecodeError) as e:print("文字起こしに失敗しました:",e,file=sys.stderr);return 1
    segments=[{"start":float(r["start"]),"end":float(r["end"]),"text":str(r.get("text","")).strip(),"words":r.get("words") or []} for r in raw.get("segments",[]) if str(r.get("text","")).strip()]
    result={"engine":engine_name,"model":model,"language":raw.get("language",a.language),"text":raw.get("text",""),"segments":segments,"review_required":True,"note":"自動文字起こしは下書きです。固有名詞、数字、区切りを音声と照合してください。"}
    (out/"transcript.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");write_srt(out/"transcript.srt",segments)
    print("文字起こし下書き:",out/"transcript.json");print("時刻付き字幕:",out/"transcript.srt");print("人の確認: 必要");return 0
if __name__=="__main__": raise SystemExit(main())
